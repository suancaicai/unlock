//
//  GesturesView.h
//  FingerprintUnlock
//
//  Created by llbt on 2018/3/19.
//  Copyright © 2018年 mm. All rights reserved.
//
#import <UIKit/UIKit.h>
//绘制解锁手势
typedef void (^SettingBlock)(int isFrist,NSArray *selectedID ,BOOL isSuccess);
//解锁  回传手势验证结果
typedef void (^UnlockBlock)(int unlockNumber,BOOL isSuccess);



@interface GesturesView : UIView

#pragma mark - 绘制手势
/**
 判断是设置手势还是手势解锁
 */
@property (nonatomic, assign) BOOL settingGesture;

@property (nonatomic, assign) int isFrist;

/**
 判断绘制成功还是失败
 */
@property (nonatomic, copy) SettingBlock   settingBlock;


#pragma mark - 解锁手势

@property (nonatomic, assign) int unlockNumber;
/**
 返回解锁成功还是失败状态
 */
@property (nonatomic, copy) UnlockBlock   unlockBlock;


//重置调用此方法
-(void)removeAllLinePath;

@end
