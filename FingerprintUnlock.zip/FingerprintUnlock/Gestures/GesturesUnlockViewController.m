//
//  GesturesUnlockViewController.m
//  FingerprintUnlock
//
//  Created by llbt on 2018/3/19.
//  Copyright © 2018年 mm. All rights reserved.
//

#import "GesturesUnlockViewController.h"
#import "GesturesView.h"

#define SELF_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SELF_HEIGHT ([UIScreen mainScreen].bounds.size.height)
#define RGBCOLOR(x,y,z) [UIColor colorWithRed:(x) / 255.0 green:(y) / 255.0 blue:(z) / 255.0 alpha:1]

@interface GesturesUnlockViewController ()
//手势解锁页面
@property (nonatomic, strong) GesturesView *gesturesView;
//手势解锁提示文本
@property (strong, nonatomic)  UILabel *hintLabel;
//设置手势成功id
@property (nonatomic, copy)  NSArray  *selectedID;
//密码存储
@property (strong, nonatomic)  UILabel *userDefaultsLabel;

@end

@implementation GesturesUnlockViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =[UIColor whiteColor];
    self.settingGesture = YES;//设置手势
    [self initView];
    [self.view addSubview:self.hintLabel];
}

- (void)initView
{
    [self.view addSubview:self.userDefaultsLabel];
    [self.view addSubview:self.gesturesView];
}
#pragma mark - 懒加载
- (GesturesView *)gesturesView
{
    if (!_gesturesView) {
        _gesturesView = [[GesturesView alloc] initWithFrame:CGRectMake(40, SELF_HEIGHT / 2.0 - (SELF_WIDTH - 80.0) / 2.0, SELF_WIDTH - 80.0, SELF_WIDTH - 80.0)];
        _gesturesView.backgroundColor = [UIColor clearColor];
        _gesturesView.settingGesture = self.settingGesture;
        __weak typeof(self) weakSelf = self;


        //设置手势，记录设置的密码，待确定后确定
        weakSelf.gesturesView.isFrist= 0;
        _gesturesView.settingBlock = ^(int isFrist, NSArray *selectedID, BOOL isSuccess){
            weakSelf.selectedID = selectedID;
            if (isFrist==0 && selectedID.count==0) {
                [[NSUserDefaults standardUserDefaults] setObject:weakSelf.selectedID forKey:@"GestureUnlock"];
                weakSelf.hintLabel.text = @"手势密码不得少于4个点";
                weakSelf.hintLabel.textColor = [UIColor redColor];
            }else if(isFrist==0 && selectedID.count>0){
                [[NSUserDefaults standardUserDefaults] setObject:weakSelf.selectedID forKey:@"GestureUnlock"];
                weakSelf.hintLabel.text = @"再次绘制解锁图案";
                weakSelf.hintLabel.textColor = [UIColor blackColor];
                weakSelf.gesturesView.isFrist++;
            }else if (!isSuccess && selectedID.count>0){
                weakSelf.hintLabel.text = @"与上次绘制不一致，请重新绘制";
                weakSelf.hintLabel.textColor = [UIColor redColor];
            }else if (isSuccess){
                weakSelf.userDefaultsLabel.hidden = NO;
                weakSelf.userDefaultsLabel.text = @"设置成功";
                weakSelf.userDefaultsLabel.textColor = [UIColor blackColor];
                weakSelf.hintLabel.text = @"设置成功，您可以尝试解锁";
                weakSelf.hintLabel.textColor = [UIColor blueColor];
                weakSelf.gesturesView.settingGesture = NO;//解锁手势
            }
            [weakSelf.gesturesView removeAllLinePath];
        };


        //解锁手势
        weakSelf.gesturesView.unlockNumber = 2;
        _gesturesView.unlockBlock = ^(int unlockNumber,BOOL isSuccess) {
            weakSelf.hintLabel.hidden = NO;
            if (!isSuccess) {
                if(unlockNumber<3 && unlockNumber!=0){
                    weakSelf.userDefaultsLabel.hidden = YES;
                    weakSelf.hintLabel.text = [NSString stringWithFormat:@"解锁失败,您还有%d次机会!", unlockNumber/1];
                    weakSelf.hintLabel.textColor = [UIColor redColor];
                    [weakSelf dismissViewControllerAnimated:NO completion:nil];
                }else if(unlockNumber<0){
                    weakSelf.hintLabel.text =@"解锁失败稍后重试";
                }
            }else{
                weakSelf.userDefaultsLabel.hidden = YES;
                weakSelf.hintLabel.textColor = [UIColor blueColor];
                weakSelf.hintLabel.text = @"解锁成功";
                [weakSelf dismissViewControllerAnimated:NO completion:nil];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"UnlockLoginSuccess" object:nil];
                });
            }
            [weakSelf.gesturesView removeAllLinePath];
        };

    }
    return _gesturesView;
}

-(UILabel *)hintLabel{

    if (!_hintLabel) {
        _hintLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 140, SELF_WIDTH - 80, 40)];
        _hintLabel.textAlignment = NSTextAlignmentCenter;
        _hintLabel.text = @"绘制解锁图案";
    }
    return _hintLabel;
}

//设置成功
-(UILabel *)userDefaultsLabel{
    if (!_userDefaultsLabel) {
        _userDefaultsLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 40, SELF_WIDTH - 80, 40)];
        _userDefaultsLabel.textAlignment = NSTextAlignmentCenter;
        _userDefaultsLabel.text = @"";
    }
    return _userDefaultsLabel;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
