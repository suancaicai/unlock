//
//  GesturesView.m
//  FingerprintUnlock
//
//  Created by llbt on 2018/3/19.
//  Copyright © 2018年 mm. All rights reserved.
//

#import "GesturesView.h"
#import "PointView.h"

#define SELF_WIDTH self.bounds.size.width
#define SELF_HEIGHT self.bounds.size.height
#define RGBCOLOR(x,y,z) [UIColor colorWithRed:(x) / 255.0 green:(y) / 255.0 blue:(z) / 255.0 alpha:1]

@interface GesturesView ()

//可变数组，用于存放初始化的点击按钮
@property (nonatomic, strong) NSMutableArray *pointViewsArray;
//记录手势滑动的起始点
@property (nonatomic, assign) CGPoint         startPoint;
//记录手势滑动的结束点
@property (nonatomic, assign) CGPoint         endPoint;
//存储选中的按钮ID
@property (nonatomic, strong) NSMutableArray  *selectedViewArray;
//手势滑动经过的点的连线
@property (nonatomic, strong) CAShapeLayer    *lineLayer;
//手势滑动的path
@property (nonatomic, strong) UIBezierPath    *linePath;
//用于存储选中的按钮
@property (nonatomic, strong) NSMutableArray   *selectedViewCenterArray;
//判断时候滑动是否结束
@property (nonatomic, assign) BOOL  touchEnd;

@end

@implementation GesturesView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initData];
        [self initView];
    }
    return self;
}
- (void)initData
{
    self.touchEnd = NO;
}

- (void)initView
{
    //初始化开始点位和结束点位
    self.startPoint = CGPointZero;
    self.endPoint = CGPointZero;
    
    //布局手势按钮
    for (int i = 0; i<9 ; i++) {

        CGFloat x = (i % 3) * (SELF_WIDTH / 2.0 - 31.0) + 1;
        CGFloat y = (i / 3) * (SELF_HEIGHT / 2.0 - 31.0) + 1;

        CGRect frame = CGRectMake(x , y, 60, 60);
        NSString *ID = [NSString stringWithFormat:@"gestures %d",i + 1];

        PointView *pointView = [[PointView alloc] initWithFrame: frame withID:ID];
        [self addSubview:pointView];
        [self.pointViewsArray addObject:pointView];
    }
}



//touch事件
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (self.touchEnd) {
        return;
    }
    
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    //判断手势滑动是否在手势按钮范围
    for (PointView *pointView in self.pointViewsArray) {
        //滑动到手势按钮范围，记录状态
        if (CGRectContainsPoint(pointView.frame, point)) {
            //如果开始按钮为zero，记录开始按钮，否则不需要记录开始按钮
            if (CGPointEqualToPoint(self.startPoint, CGPointZero)) {
                self.startPoint = pointView.center;
            }
            //判断该手势按钮的中心点是否记录，未记录则记录
            if (![self.selectedViewCenterArray containsObject:[NSValue valueWithCGPoint:pointView.center]]) {
                [self.selectedViewCenterArray addObject:[NSValue valueWithCGPoint:pointView.center]];
            }
            //判断该手势按钮是否已经选中，未选中就选中
            if (![self.selectedViewArray containsObject:pointView.ID]) {
                [self.selectedViewArray addObject:pointView.ID];
                pointView.isSelected = YES;
            }
        }
    }
    //如果开始点位不为zero则记录结束点位，否则跳过不记录
    if (!CGPointEqualToPoint(self.startPoint, CGPointZero)) {
        self.endPoint = point;
        [self drawLines];
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    //结束手势滑动的时候，将结束按钮设置为最后一个手势按钮的中心点，并画线
    self.endPoint = [self.selectedViewCenterArray.lastObject CGPointValue];
    //如果endPoint还是为zero说明未滑动到有效位置，不做处理
    if (CGPointEqualToPoint(self.endPoint, CGPointZero)) {
        return;
    }
    [self drawLines];
    //改变手势滑动结束的状态，为yes则无法在滑动手势划线
    self.touchEnd = YES;

    [[NSUserDefaults standardUserDefaults] setObject:self.selectedViewArray forKey:@"selectedViewArray"];

    //设置手势时，返回设置的时候密码，否则继续下面的操作进行手势绘制
    if (_settingBlock && _settingGesture) {
        //手势密码不得小于4个点[第一次输入进行提示]
        if (self.selectedViewArray.count < 4 && _isFrist==0) {
            [self removeAllLinePath];
            self.settingBlock(_isFrist, self.selectedViewArray, YES);
            return;
        } else {
            //绘制是否成功
            NSMutableArray *selectedID = [[NSUserDefaults standardUserDefaults] objectForKey:@"GestureUnlock"];
            NSMutableArray *selectedViewArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"selectedViewArray"];
            if ([self compareArray:selectedViewArray andArr2:selectedID]) {
                self.settingBlock(_isFrist, self.selectedViewArray, YES);
            }else{
                self.settingBlock(_isFrist, self.selectedViewArray, NO);
            }
            return;
            
        }
    }else{
        //解锁手势
        //绘制是否成功
        NSMutableArray *selectedID = [[NSUserDefaults standardUserDefaults] objectForKey:@"GestureUnlock"];
        NSMutableArray *selectedViewArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"selectedViewArray"];
        if ([self compareArray:selectedViewArray andArr2:selectedID]) {
            //解锁成功，遍历pointview，设置为成功状态
//            for (PointView *pointView in self.pointViewsArray) {
//                pointView.isSuccess = YES;
//            }
//            self.lineLayer.strokeColor = RGBCOLOR(43.0, 210.0, 110.0).CGColor;
            self.unlockBlock(_unlockNumber--,YES);
        }else{
            self.unlockBlock(_unlockNumber--,NO);
        }
    }
}

- (BOOL)compareArray:(NSMutableArray *)arr1 andArr2:(NSMutableArray *)arr2 {
    bool bol = false;
    if (arr2.count == arr1.count) {//判断数据是否相等
        bol = true;
        //遍历比较数组数据的内容
        for (int16_t i = 0; i < arr1.count; i++) {
            if (![[arr2 objectAtIndex:i] isEqualToString:[arr1 objectAtIndex:i]]) {
                bol = false;
                break;
            }
        }
    }
    return bol? YES:NO;
}


//不允许重复绘制
- (void)drawLines
{
    //结束手势滑动，不画线
    if (self.touchEnd) {
        return;
    }
    //移除path的点和lineLayer
    [self.lineLayer removeFromSuperlayer];
    [self.linePath removeAllPoints];
    //画线
    [self.linePath moveToPoint:self.startPoint];

    for (NSValue *pointValue in self.selectedViewCenterArray) {
        
        [self.linePath addLineToPoint:[pointValue CGPointValue]];
    }
    [self.linePath addLineToPoint:self.endPoint];
    
    self.lineLayer.path = self.linePath.CGPath;
    self.lineLayer.lineWidth = 4.0;
    self.lineLayer.strokeColor = RGBCOLOR(30.0, 180.0, 244.0).CGColor;
    self.lineLayer.fillColor = [UIColor clearColor].CGColor;
    
    [self.layer addSublayer:self.lineLayer];
    
    self.layer.masksToBounds = YES;
}

//移除手势痕迹
-(void)removeAllLinePath{
    self.touchEnd = NO;
    for (PointView *pointView in self.pointViewsArray) {
        pointView.isSelected = NO;
    }
    [self.lineLayer removeFromSuperlayer];
    [self.selectedViewArray removeAllObjects];
    self.startPoint = CGPointZero;
    self.endPoint = CGPointZero;
    [self.selectedViewCenterArray removeAllObjects];
}

#pragma mark - setter
- (void)setSettingGesture:(BOOL)settingGesture
{
    _settingGesture = settingGesture;
}


#pragma mark - 懒加载
- (NSMutableArray *)pointViewsArray
{
    if (!_pointViewsArray) {
        _pointViewsArray = [NSMutableArray arrayWithCapacity:9];
    }
    return _pointViewsArray;
}

- (NSMutableArray *)selectedViewArray
{
    if (!_selectedViewArray) {
        _selectedViewArray = [NSMutableArray array];
    }
    return _selectedViewArray;
}

- (NSMutableArray *)selectedViewCenterArray
{
    if (!_selectedViewCenterArray) {
        _selectedViewCenterArray = [NSMutableArray array];
    }
    return _selectedViewCenterArray;
}


- (UIBezierPath *)linePath
{
    if (!_linePath) {
        _linePath = [UIBezierPath bezierPath];
    }
    return _linePath;
}
- (CAShapeLayer *)lineLayer
{
    if (!_lineLayer) {
        _lineLayer = [CAShapeLayer layer];
    }
    return _lineLayer;
}

@end
