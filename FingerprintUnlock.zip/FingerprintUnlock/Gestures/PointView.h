//
//  PointView.h
//  FingerprintUnlock
//
//  Created by llbt on 2018/3/19.
//  Copyright © 2018年 mm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PointView : UIView
@property (nonatomic, copy, readonly) NSString  *ID;
@property (nonatomic, assign) BOOL  isSelected;//选中
@property (nonatomic, assign) BOOL  isError;//解锁失败  **未使用
@property (nonatomic, assign) BOOL  isSuccess;//解锁成功

- (instancetype)initWithFrame:(CGRect)frame withID:(NSString *)ID;

@end
