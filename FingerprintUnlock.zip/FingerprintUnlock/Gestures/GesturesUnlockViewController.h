//
//  GesturesUnlockViewController.h
//  FingerprintUnlock
//
//  Created by llbt on 2018/3/19.
//  Copyright © 2018年 mm. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface GesturesUnlockViewController : UIViewController
//判断是否为设置手势  还是解锁手势
@property (nonatomic, assign) BOOL settingGesture;

@end
